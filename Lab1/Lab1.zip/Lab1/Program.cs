﻿using System;
using Lab1;

internal class Program
{
    public static void Main()
    {
        int M = 5;
        TableOfVectors A = new TableOfVectors(height: 1000, width: 1000, fillWithInts: true);

        double x, y, z;
        Console.WriteLine("Input vector:");
        string[] input = Console.ReadLine().Split();
        x = Convert.ToDouble(input[0]);
        y = Convert.ToDouble(input[1]);
        z = Convert.ToDouble(input[2]);
        R3Vector userVector = new R3Vector(x, y, z);
        //A.Print();

        R3Vector[][] B = A.RetrieveVectors(magnitude: M);
        //PrintArray(B);

        Console.WriteLine($"{CountCollinearVectors(B, userVector)} vectors from B were found " +
            $"collinear with user vector ({userVector.x}, {userVector.y}, {userVector.z})");
    }

    public static void PrintArray(R3Vector[][] array)
    {
        Console.WriteLine("TABLE OF RETRIEVED VECTORS");
        Console.WriteLine($"{new string('#', 26)}");
        for (int i = 0; i < array.Length; ++i)
        {
            Console.Write($"{i + 1, 2}: ");
            for (int j = 0; j < array[i].Length; ++j)
            {
                Console.Write($"({array[i][j].x,0:F2}, {array[i][j].y,4:F2}, {array[i][j].z,4:F2})");
                Console.Write(new string(' ', 3));
            }
            if (array[i].Length == 0) { Console.Write("No vectors"); }
            Console.Write(new string('\n', 2));
        }
    }

    public static int CountCollinearVectors(R3Vector[][] table, R3Vector userVector)
    {
        int counter = 0;

        foreach (R3Vector[] array in table)
        {
            foreach (R3Vector vector in array)
            {
                if (vector | userVector) { counter += 1; }
            }
        }

        return counter;
    }
}